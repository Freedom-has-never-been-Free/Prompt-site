# Deploying the Prompt Library

## Vercel (recommended)
1. Push this repo to GitHub
2. In Vercel, import the repo
3. Deploy (defaults work)

## Notes
This site includes a server route for JSON export at /api/export/json
