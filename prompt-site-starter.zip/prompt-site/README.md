# Prompt Library

A small Next.js prompt library you can deploy and extend.

## Run locally
npm install
npm run dev

## Data
Edit:
- data/prompts.json
- data/packs.json
- data/categories.json

## Export
/export downloads JSON export
